import { getAccessToken } from './firebaseAuth';
import { Product } from '../types/store';

export interface SlideExportResult {
  presentationId: string;
  presentationUrl: string;
  title: string;
}

/**
 * Creates a Google Slides presentation showcasing the store's product catalog.
 */
export async function exportCatalogToGoogleSlides(
  storeName: string,
  tagline: string,
  products: Product[]
): Promise<SlideExportResult> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Please sign in with Google first.');
  }

  // 1. Create a new presentation
  const title = `${storeName} - Product Catalog (${new Date().toLocaleDateString()})`;
  const createRes = await fetch('https://slides.googleapis.com/v1/presentations', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ title }),
  });

  if (!createRes.ok) {
    const errorData = await createRes.json();
    throw new Error(errorData.error?.message || 'Failed to create Google Slides presentation');
  }

  const presentation = await createRes.json();
  const presentationId = presentation.presentationId;

  // 2. Prepare batch update requests for product slides
  const requests: any[] = [];
  const selectedProducts = products.slice(0, 8); // Top items for a clean deck

  selectedProducts.forEach((product, index) => {
    const slideId = `slide_prod_${index}_${Date.now()}`;
    const titleBoxId = `title_${index}_${Date.now()}`;
    const descBoxId = `desc_${index}_${Date.now()}`;
    const priceBoxId = `price_${index}_${Date.now()}`;
    const imageId = `img_${index}_${Date.now()}`;

    // Create slide
    requests.push({
      createSlide: {
        objectId: slideId,
        insertionIndex: index + 1,
        slideLayoutReference: { predefinedLayout: 'BLANK' },
      },
    });

    // Add Title Box
    requests.push({
      createShape: {
        objectId: titleBoxId,
        shapeType: 'TEXT_BOX',
        elementProperties: {
          pageObjectId: slideId,
          size: { width: { magnitude: 500, unit: 'PT' }, height: { magnitude: 50, unit: 'PT' } },
          transform: { scaleX: 1, scaleY: 1, translateX: 50, translateY: 40, unit: 'PT' },
        },
      },
    });
    requests.push({
      insertText: {
        objectId: titleBoxId,
        text: product.name,
      },
    });

    // Add Price and Category Box
    const priceText = `Price: Rs. ${product.price.toLocaleString()} | Category: ${product.category.toUpperCase()} | Stock: ${product.stock} units`;
    requests.push({
      createShape: {
        objectId: priceBoxId,
        shapeType: 'TEXT_BOX',
        elementProperties: {
          pageObjectId: slideId,
          size: { width: { magnitude: 450, unit: 'PT' }, height: { magnitude: 35, unit: 'PT' } },
          transform: { scaleX: 1, scaleY: 1, translateX: 50, translateY: 95, unit: 'PT' },
        },
      },
    });
    requests.push({
      insertText: {
        objectId: priceBoxId,
        text: priceText,
      },
    });

    // Add Description Box
    requests.push({
      createShape: {
        objectId: descBoxId,
        shapeType: 'TEXT_BOX',
        elementProperties: {
          pageObjectId: slideId,
          size: { width: { magnitude: 380, unit: 'PT' }, height: { magnitude: 180, unit: 'PT' } },
          transform: { scaleX: 1, scaleY: 1, translateX: 50, translateY: 140, unit: 'PT' },
        },
      },
    });
    requests.push({
      insertText: {
        objectId: descBoxId,
        text: `${product.description}\n\n• SKU: ${product.sku}\n• Rating: ${product.rating} / 5 (${product.reviewsCount} customer reviews)`,
      },
    });

    // Add Image element if valid URL
    if (product.image && product.image.startsWith('http')) {
      requests.push({
        createImage: {
          objectId: imageId,
          url: product.image,
          elementProperties: {
            pageObjectId: slideId,
            size: { width: { magnitude: 220, unit: 'PT' }, height: { magnitude: 220, unit: 'PT' } },
            transform: { scaleX: 1, scaleY: 1, translateX: 450, translateY: 120, unit: 'PT' },
          },
        },
      });
    }
  });

  if (requests.length > 0) {
    const updateRes = await fetch(
      `https://slides.googleapis.com/v1/presentations/${presentationId}:batchUpdate`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ requests }),
      }
    );

    if (!updateRes.ok) {
      console.warn('Batch update slide content warning:', await updateRes.text());
    }
  }

  return {
    presentationId,
    presentationUrl: `https://docs.google.com/presentation/d/${presentationId}/edit`,
    title,
  };
}
