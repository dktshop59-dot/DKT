export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: string;
  stock: number;
  sku: string;
  image: string;
  featured?: boolean;
  badge?: 'Hot' | 'Sale' | 'New' | 'Popular' | 'Best Seller';
  rating: number;
  reviewsCount: number;
  specs?: { label: string; value: string }[];
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  iconName?: string;
  color?: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  branch: string;
  instructions?: string;
  isActive: boolean;
  isPrimary: boolean;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  announcementText: string;
  showAnnouncement: boolean;
  logoUrl?: string;
  primaryColor: 'indigo' | 'rose' | 'emerald' | 'violet' | 'amber' | 'cyan';
  currency: string;
  currencyCode: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  businessRegNumber: string;
  heroTitle: string;
  heroSubtitle: string;
  heroBadge: string;
  heroImage: string;
  freeShippingThreshold: number;
  standardShippingFee: number;
  adminPassword?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type PaymentMethod = 'card' | 'bank_transfer' | 'cod' | 'digital_wallet';
export type PaymentStatus = 'paid' | 'pending_verification' | 'pending_cod' | 'failed';
export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  city: string;
  postalCode: string;
  items: CartItem[];
  subtotal: number;
  shippingFee: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  bankAccountId?: string;
  bankSlipUrl?: string;
  bankTransferRef?: string;
  notes?: string;
  createdAt: string;
}
