import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  BankAccount,
  CartItem,
  Category,
  Order,
  OrderStatus,
  PaymentMethod,
  PaymentStatus,
  Product,
  StoreSettings,
} from '../types/store';
import {
  INITIAL_BANK_ACCOUNTS,
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_SETTINGS,
} from '../data/seedData';

interface StoreContextType {
  products: Product[];
  categories: Category[];
  bankAccounts: BankAccount[];
  settings: StoreSettings;
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  currentView: 'store' | 'admin';
  setCurrentView: (view: 'store' | 'admin') => void;
  adminTab: 'overview' | 'settings' | 'inventory' | 'bank_accounts' | 'orders' | 'slides';
  setAdminTab: (tab: 'overview' | 'settings' | 'inventory' | 'bank_accounts' | 'orders' | 'slides') => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  viewingProduct: Product | null;
  setViewingProduct: (product: Product | null) => void;
  lastPlacedOrder: Order | null;
  setLastPlacedOrder: (order: Order | null) => void;
  isAdminAuthenticated: boolean;
  isAdminAuthModalOpen: boolean;
  setIsAdminAuthModalOpen: (open: boolean) => void;
  openAdminPanel: () => void;
  adminLogin: (password: string) => boolean;
  adminLogout: () => void;
  changeAdminPassword: (newPassword: string) => void;

  // Actions
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  adjustStock: (id: string, delta: number) => void;

  addBankAccount: (account: Omit<BankAccount, 'id'>) => void;
  updateBankAccount: (id: string, updates: Partial<BankAccount>) => void;
  deleteBankAccount: (id: string) => void;
  setPrimaryBankAccount: (id: string) => void;

  updateSettings: (updates: Partial<StoreSettings>) => void;

  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartItemCount: number;

  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;

  placeOrder: (orderData: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    shippingAddress: string;
    city: string;
    postalCode: string;
    paymentMethod: PaymentMethod;
    bankAccountId?: string;
    bankSlipUrl?: string;
    bankTransferRef?: string;
    notes?: string;
  }) => Order;
  updateOrderStatus: (orderId: string, orderStatus: OrderStatus, paymentStatus?: PaymentStatus) => void;
  resetToDefaults: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const SAMPLE_ORDERS: Order[] = [
  {
    id: 'ORD-1082',
    customerName: 'Kavindu Perera',
    customerEmail: 'kavindu.p@gmail.com',
    customerPhone: '+94 77 892 1144',
    shippingAddress: '45/2 Duplication Road, Bambalapitiya',
    city: 'Colombo',
    postalCode: '00400',
    items: [
      { product: INITIAL_PRODUCTS[0], quantity: 1 },
      { product: INITIAL_PRODUCTS[4], quantity: 1 },
    ],
    subtotal: 44300,
    shippingFee: 0,
    discount: 0,
    total: 44300,
    paymentMethod: 'bank_transfer',
    paymentStatus: 'pending_verification',
    orderStatus: 'pending',
    bankAccountId: 'bank-1',
    bankTransferRef: 'TXN-902148201',
    bankSlipUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
    notes: 'Please ring bell upon arrival.',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
  },
  {
    id: 'ORD-1081',
    customerName: 'Dilani Samarasinghe',
    customerEmail: 'dilani.samara@yahoo.com',
    customerPhone: '+94 71 455 9022',
    shippingAddress: '12 Havelock Road',
    city: 'Colombo',
    postalCode: '00500',
    items: [
      { product: INITIAL_PRODUCTS[1], quantity: 1 },
    ],
    subtotal: 21900,
    shippingFee: 0,
    discount: 1000,
    total: 20900,
    paymentMethod: 'card',
    paymentStatus: 'paid',
    orderStatus: 'processing',
    createdAt: new Date(Date.now() - 3600000 * 18).toISOString(),
  },
  {
    id: 'ORD-1080',
    customerName: 'Roshan Fernando',
    customerEmail: 'roshan.f@hotmail.com',
    customerPhone: '+94 76 331 8721',
    shippingAddress: '88 Negombo Road, Wattala',
    city: 'Gampaha',
    postalCode: '11300',
    items: [
      { product: INITIAL_PRODUCTS[3], quantity: 1 },
      { product: INITIAL_PRODUCTS[5], quantity: 1 },
    ],
    subtotal: 20100,
    shippingFee: 0,
    discount: 0,
    total: 20100,
    paymentMethod: 'cod',
    paymentStatus: 'pending_cod',
    orderStatus: 'shipped',
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
  },
];

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Products
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('aurastore_products');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  // Categories
  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const saved = localStorage.getItem('aurastore_categories');
      return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
    } catch {
      return INITIAL_CATEGORIES;
    }
  });

  // Bank Accounts
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => {
    try {
      const saved = localStorage.getItem('aurastore_banks');
      return saved ? JSON.parse(saved) : INITIAL_BANK_ACCOUNTS;
    } catch {
      return INITIAL_BANK_ACCOUNTS;
    }
  });

  // Settings
  const [settings, setSettings] = useState<StoreSettings>(() => {
    try {
      const saved = localStorage.getItem('aurastore_settings');
      return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  // Cart & Wishlist
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('aurastore_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('aurastore_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('aurastore_orders');
      return saved ? JSON.parse(saved) : SAMPLE_ORDERS;
    } catch {
      return SAMPLE_ORDERS;
    }
  });

  // UI state
  const [currentView, setCurrentView] = useState<'store' | 'admin'>('store');
  const [adminTab, setAdminTab] = useState<'overview' | 'settings' | 'inventory' | 'bank_accounts' | 'orders' | 'slides'>('overview');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('featured');
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [viewingProduct, setViewingProduct] = useState<Product | null>(null);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('aurastore_admin_auth') === 'true';
    } catch {
      return false;
    }
  });
  const [isAdminAuthModalOpen, setIsAdminAuthModalOpen] = useState<boolean>(false);

  const openAdminPanel = () => {
    if (isAdminAuthenticated) {
      setCurrentView('admin');
    } else {
      setIsAdminAuthModalOpen(true);
    }
  };

  const adminLogin = (passwordInput: string): boolean => {
    const validPassword = settings.adminPassword || 'admin123';
    if (passwordInput === validPassword) {
      setIsAdminAuthenticated(true);
      try {
        sessionStorage.setItem('aurastore_admin_auth', 'true');
      } catch (e) {
        console.warn('sessionStorage error', e);
      }
      setIsAdminAuthModalOpen(false);
      setCurrentView('admin');
      return true;
    }
    return false;
  };

  const adminLogout = () => {
    setIsAdminAuthenticated(false);
    try {
      sessionStorage.removeItem('aurastore_admin_auth');
    } catch (e) {
      console.warn('sessionStorage error', e);
    }
    setCurrentView('store');
  };

  const changeAdminPassword = (newPassword: string) => {
    updateSettings({ adminPassword: newPassword });
  };

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('aurastore_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('aurastore_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('aurastore_banks', JSON.stringify(bankAccounts));
  }, [bankAccounts]);

  useEffect(() => {
    localStorage.setItem('aurastore_settings', JSON.stringify(settings));
    document.title = `${settings.storeName} - ${settings.tagline}`;
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('aurastore_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('aurastore_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('aurastore_orders', JSON.stringify(orders));
  }, [orders]);

  // Product Actions
  const addProduct = (productData: Omit<Product, 'id' | 'createdAt'>) => {
    const newProduct: Product = {
      ...productData,
      id: `prod-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setProducts((prev) => [newProduct, ...prev]);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((item) => item.id !== id));
    setCart((prev) => prev.filter((item) => item.product.id !== id));
  };

  const adjustStock = (id: string, delta: number) => {
    setProducts((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newStock = Math.max(0, item.stock + delta);
          return { ...item, stock: newStock };
        }
        return item;
      })
    );
  };

  // Bank Account Actions
  const addBankAccount = (accountData: Omit<BankAccount, 'id'>) => {
    const newAccount: BankAccount = {
      ...accountData,
      id: `bank-${Date.now()}`,
      isPrimary: bankAccounts.length === 0 ? true : !!accountData.isPrimary,
    };
    if (newAccount.isPrimary) {
      setBankAccounts((prev) => [
        ...prev.map((acc): BankAccount => ({ ...acc, isPrimary: false })),
        newAccount,
      ]);
    } else {
      setBankAccounts((prev) => [...prev, newAccount]);
    }
  };

  const updateBankAccount = (id: string, updates: Partial<BankAccount>) => {
    setBankAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === id) {
          return { ...acc, ...updates };
        }
        if (updates.isPrimary) {
          return { ...acc, isPrimary: false };
        }
        return acc;
      })
    );
  };

  const deleteBankAccount = (id: string) => {
    setBankAccounts((prev) => prev.filter((acc) => acc.id !== id));
  };

  const setPrimaryBankAccount = (id: string) => {
    setBankAccounts((prev) =>
      prev.map((acc) => ({ ...acc, isPrimary: acc.id === id }))
    );
  };

  // Store Settings
  const updateSettings = (updates: Partial<StoreSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  };

  // Cart Actions
  const addToCart = (product: Product, quantity = 1) => {
    if (product.stock <= 0) return;
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        const newQty = Math.min(product.stock, existing.quantity + quantity);
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: newQty } : item
        );
      }
      return [...prev, { product, quantity: Math.min(product.stock, quantity) }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          const validQty = Math.min(item.product.stock, quantity);
          return { ...item, quantity: validQty };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotal = cart.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Wishlist Actions
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  // Orders
  const placeOrder = (orderData: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    shippingAddress: string;
    city: string;
    postalCode: string;
    paymentMethod: PaymentMethod;
    bankAccountId?: string;
    bankSlipUrl?: string;
    bankTransferRef?: string;
    notes?: string;
  }): Order => {
    const subtotal = cartTotal;
    const shippingFee = subtotal >= settings.freeShippingThreshold ? 0 : settings.standardShippingFee;
    const discount = 0;
    const total = subtotal + shippingFee - discount;

    let paymentStatus: PaymentStatus = 'pending_verification';
    if (orderData.paymentMethod === 'card' || orderData.paymentMethod === 'digital_wallet') {
      paymentStatus = 'paid';
    } else if (orderData.paymentMethod === 'cod') {
      paymentStatus = 'pending_cod';
    }

    const newOrder: Order = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: orderData.customerName,
      customerEmail: orderData.customerEmail,
      customerPhone: orderData.customerPhone,
      shippingAddress: orderData.shippingAddress,
      city: orderData.city,
      postalCode: orderData.postalCode,
      items: [...cart],
      subtotal,
      shippingFee,
      discount,
      total,
      paymentMethod: orderData.paymentMethod,
      paymentStatus,
      orderStatus: 'pending',
      bankAccountId: orderData.bankAccountId,
      bankSlipUrl: orderData.bankSlipUrl,
      bankTransferRef: orderData.bankTransferRef,
      notes: orderData.notes,
      createdAt: new Date().toISOString(),
    };

    // Deduct stock
    cart.forEach((item) => {
      adjustStock(item.product.id, -item.quantity);
    });

    setOrders((prev) => [newOrder, ...prev]);
    setLastPlacedOrder(newOrder);
    clearCart();
    setIsCheckoutOpen(false);

    return newOrder;
  };

  const updateOrderStatus = (
    orderId: string,
    orderStatus: OrderStatus,
    paymentStatus?: PaymentStatus
  ) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          return {
            ...order,
            orderStatus,
            paymentStatus: paymentStatus || order.paymentStatus,
          };
        }
        return order;
      })
    );
  };

  const resetToDefaults = () => {
    setProducts(INITIAL_PRODUCTS);
    setCategories(INITIAL_CATEGORIES);
    setBankAccounts(INITIAL_BANK_ACCOUNTS);
    setSettings(INITIAL_SETTINGS);
    setOrders(SAMPLE_ORDERS);
    setCart([]);
    setWishlist([]);
    localStorage.clear();
  };

  return (
    <StoreContext.Provider
      value={{
        products,
        categories,
        bankAccounts,
        settings,
        cart,
        wishlist,
        orders,
        currentView,
        setCurrentView,
        adminTab,
        setAdminTab,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        sortBy,
        setSortBy,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        viewingProduct,
        setViewingProduct,
        lastPlacedOrder,
        setLastPlacedOrder,
        isAdminAuthenticated,
        isAdminAuthModalOpen,
        setIsAdminAuthModalOpen,
        openAdminPanel,
        adminLogin,
        adminLogout,
        changeAdminPassword,

        addProduct,
        updateProduct,
        deleteProduct,
        adjustStock,

        addBankAccount,
        updateBankAccount,
        deleteBankAccount,
        setPrimaryBankAccount,

        updateSettings,

        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartTotal,
        cartItemCount,

        toggleWishlist,
        isWishlisted,

        placeOrder,
        updateOrderStatus,
        resetToDefaults,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
