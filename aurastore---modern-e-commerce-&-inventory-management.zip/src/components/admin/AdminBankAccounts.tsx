import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Star,
  Copy,
  Info,
  X,
  Check,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { BankAccount } from '../../types/store';

const POPULAR_BANKS = [
  'Commercial Bank of Ceylon',
  'Sampath Bank PLC',
  'Bank of Ceylon (BOC)',
  'Hatton National Bank (HNB)',
  'Nations Trust Bank (NTB)',
  'Seylan Bank PLC',
  'People\'s Bank',
  'DFCC Bank',
  'Standard Chartered',
  'HSBC Sri Lanka',
];

export const AdminBankAccounts: React.FC = () => {
  const { bankAccounts, addBankAccount, updateBankAccount, deleteBankAccount, setPrimaryBankAccount } =
    useStore();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<BankAccount | null>(null);

  // Form Fields
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [branch, setBranch] = useState('');
  const [instructions, setInstructions] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [isPrimary, setIsPrimary] = useState(false);

  const openAddModal = () => {
    setEditingAccount(null);
    setBankName(POPULAR_BANKS[0]);
    setAccountNumber('');
    setAccountName('AuraStore Retail Holdings');
    setBranch('Colombo Corporate Branch');
    setInstructions('Please include your Order ID in reference and upload your deposit slip photo.');
    setIsActive(true);
    setIsPrimary(bankAccounts.length === 0);
    setIsModalOpen(true);
  };

  const openEditModal = (acc: BankAccount) => {
    setEditingAccount(acc);
    setBankName(acc.bankName);
    setAccountNumber(acc.accountNumber);
    setAccountName(acc.accountName);
    setBranch(acc.branch);
    setInstructions(acc.instructions || '');
    setIsActive(acc.isActive);
    setIsPrimary(!!acc.isPrimary);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bankName.trim() || !accountNumber.trim() || !accountName.trim() || !branch.trim()) {
      alert('Please fill in bank name, account number, account holder name, and branch.');
      return;
    }

    if (editingAccount) {
      updateBankAccount(editingAccount.id, {
        bankName,
        accountNumber,
        accountName,
        branch,
        instructions,
        isActive,
        isPrimary,
      });
    } else {
      addBankAccount({
        bankName,
        accountNumber,
        accountName,
        branch,
        instructions,
        isActive,
        isPrimary,
      });
    }

    setIsModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete bank account "${name}"?`)) {
      deleteBankAccount(id);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-indigo-600" />
            <span>Store Bank Accounts Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure bank accounts where customers can deposit payments via Online Transfer or Cash Deposit.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-extrabold px-5 py-2.5 rounded-xl shadow-md shadow-indigo-500/20 active:scale-95 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Bank Account</span>
        </button>
      </div>

      {/* Info notice */}
      <div className="p-4 bg-indigo-50/70 border border-indigo-200 text-indigo-950 rounded-2xl flex items-start gap-3 text-xs leading-relaxed">
        <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">How Direct Bank Transfers work:</span> Active bank accounts
          appear on the customer checkout page under "Direct Bank Transfer". Customers can 1-click
          copy the account number, complete the transfer, and upload their bank slip photo or
          transaction reference. You can then review and verify their payment under the Orders tab!
        </div>
      </div>

      {/* Bank Accounts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {bankAccounts.length === 0 ? (
          <div className="col-span-full bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-400">
            No bank accounts configured yet. Click "Add New Bank Account" to add your store's first bank account!
          </div>
        ) : (
          bankAccounts.map((account) => (
            <div
              key={account.id}
              className={`p-5 rounded-2xl border transition-all flex flex-col justify-between relative bg-white ${
                account.isPrimary
                  ? 'border-indigo-400 ring-2 ring-indigo-500/10 shadow-md'
                  : 'border-slate-200 hover:border-slate-300 shadow-xs'
              }`}
            >
              <div>
                {/* Bank badge & status */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-slate-900 leading-tight">
                        {account.bankName}
                      </h4>
                      <p className="text-[11px] text-slate-500">{account.branch}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {account.isPrimary && (
                      <span className="text-[10px] font-extrabold bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Star className="w-3 h-3 fill-indigo-700" /> Primary
                      </span>
                    )}
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        account.isActive ? 'bg-emerald-500' : 'bg-slate-300'
                      }`}
                      title={account.isActive ? 'Active on Checkout' : 'Inactive'}
                    />
                  </div>
                </div>

                {/* Account Details Box */}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs font-sans mt-3">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 font-medium">Account No:</span>
                    <span className="font-mono font-black text-slate-900 text-sm">
                      {account.accountNumber}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 font-medium">Account Name:</span>
                    <span className="font-semibold text-slate-800 text-right truncate max-w-[160px]">
                      {account.accountName}
                    </span>
                  </div>
                  {account.instructions && (
                    <div className="pt-2 border-t border-slate-200/60 text-[11px] text-slate-600 italic">
                      "{account.instructions}"
                    </div>
                  )}
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  {!account.isPrimary && (
                    <button
                      onClick={() => setPrimaryBankAccount(account.id)}
                      className="text-indigo-600 hover:text-indigo-800 font-bold hover:underline"
                    >
                      Make Primary
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEditModal(account)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                    title="Edit account"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(account.id, account.bankName)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Delete account"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add / Edit Bank Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 relative my-6">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <Building2 className="w-5 h-5 text-indigo-400" />
                <h3 className="font-extrabold text-base">
                  {editingAccount ? 'Edit Bank Account' : 'Add New Bank Account'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Bank Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  list="popular-banks"
                  placeholder="e.g. Commercial Bank of Ceylon"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden font-bold"
                />
                <datalist id="popular-banks">
                  {POPULAR_BANKS.map((b, i) => (
                    <option key={i} value={b} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Account Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 8004593812"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden font-mono font-black"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Account Holder Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AuraStore Retail Holdings (Pvt) Ltd"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Branch Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Colombo City Branch"
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Special Deposit Instructions <span className="text-slate-400 font-normal">(shown to customer)</span>
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Please put your Order ID as reference and upload payment receipt."
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden resize-none"
                />
              </div>

              <div className="flex items-center gap-6 pt-1">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Active for Customers</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isPrimary}
                    onChange={(e) => setIsPrimary(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Default / Primary Account</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl shadow-md transition-all cursor-pointer"
                >
                  {editingAccount ? 'Save Changes' : 'Add Bank Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
