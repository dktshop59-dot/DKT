import React, { useState } from 'react';
import {
  LayoutDashboard,
  Palette,
  Package,
  Building2,
  ShoppingBag,
  Presentation,
  Store,
  ArrowLeft,
  Sparkles,
  Lock,
  LogOut,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { AdminOverview } from './AdminOverview';
import { AdminStoreCustomizer } from './AdminStoreCustomizer';
import { AdminInventory } from './AdminInventory';
import { AdminBankAccounts } from './AdminBankAccounts';
import { AdminOrders } from './AdminOrders';
import { AdminSlidesExport } from './AdminSlidesExport';

export const AdminDashboard: React.FC = () => {
  const {
    adminTab,
    setAdminTab,
    setCurrentView,
    settings,
    orders,
    products,
    isAdminAuthenticated,
    adminLogout,
    setIsAdminAuthModalOpen,
  } = useStore();

  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center p-6 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center shadow-inner">
          <Lock className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-2xl font-black text-slate-900">Admin Area Locked</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-sm mx-auto">
            Please enter the admin password to access store settings, inventory, and orders.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('store')}
            className="px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50"
          >
            Back to Store
          </button>
          <button
            onClick={() => setIsAdminAuthModalOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold shadow-md shadow-indigo-600/20"
          >
            Enter Password
          </button>
        </div>
      </div>
    );
  }

  const pendingOrdersCount = orders.filter(
    (o) => o.paymentStatus === 'pending_verification'
  ).length;
  const lowStockCount = products.filter((p) => p.stock <= 5).length;

  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'settings', label: 'Store Name & Brand', icon: Palette },
    {
      id: 'inventory',
      label: 'Inventory Management',
      icon: Package,
      badge: lowStockCount > 0 ? `${lowStockCount} low` : undefined,
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    { id: 'bank_accounts', label: 'Bank Accounts', icon: Building2 },
    {
      id: 'orders',
      label: 'Customer Orders',
      icon: ShoppingBag,
      badge: pendingOrdersCount > 0 ? `${pendingOrdersCount} new` : undefined,
      badgeColor: 'bg-rose-100 text-rose-700',
    },
    { id: 'slides', label: 'Google Slides Deck', icon: Presentation },
  ];

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 pb-16">
      {/* Admin Top Navigation Bar */}
      <div className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentView('store')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>View Storefront</span>
              </button>

              <div className="h-5 w-px bg-slate-800 hidden sm:block"></div>

              <div>
                <span className="font-extrabold text-sm sm:text-base tracking-tight text-white flex items-center gap-2">
                  <span>{settings.storeName}</span>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 px-2 py-0.5 rounded-md">
                    Admin Portal
                  </span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="hidden sm:inline text-xs text-slate-400">
                Logged in as <strong className="text-white">Store Owner</strong>
              </span>

              <button
                onClick={adminLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-slate-300 hover:text-rose-300 text-xs font-bold transition-all cursor-pointer"
                title="Lock Admin Panel"
              >
                <Lock className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden sm:inline">Lock Admin</span>
              </button>
            </div>
          </div>

          {/* Sub Navigation Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto py-2 -mb-px border-t border-slate-800/80 scrollbar-none">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = adminTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setAdminTab(item.id as any)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                        isActive ? 'bg-white text-indigo-700' : item.badgeColor
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content View */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {adminTab === 'overview' && (
          <AdminOverview
            onNavigateTab={(tab) => setAdminTab(tab)}
            onOpenAddProduct={() => setAdminTab('inventory')}
          />
        )}
        {adminTab === 'settings' && <AdminStoreCustomizer />}
        {adminTab === 'inventory' && <AdminInventory />}
        {adminTab === 'bank_accounts' && <AdminBankAccounts />}
        {adminTab === 'orders' && <AdminOrders />}
        {adminTab === 'slides' && <AdminSlidesExport />}
      </div>
    </div>
  );
};
