import React, { useState } from 'react';
import {
  Package,
  Plus,
  Search,
  Edit2,
  Trash2,
  AlertTriangle,
  Check,
  X,
  Upload,
  Image as ImageIcon,
  Tag,
  DollarSign,
  Layers,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { Product } from '../../types/store';

const CURATED_IMAGES = [
  { label: 'Headphones', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80' },
  { label: 'Smart Watch', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80' },
  { label: 'Keyboard', url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800&auto=format&fit=crop&q=80' },
  { label: 'Backpack', url: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80' },
  { label: 'Cosmetics Serum', url: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=800&auto=format&fit=crop&q=80' },
  { label: 'Bluetooth Speaker', url: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?w=800&auto=format&fit=crop&q=80' },
  { label: 'Smart Bottle', url: 'https://images.unsplash.com/photo-1517256064527-09c73fc73e38?w=800&auto=format&fit=crop&q=80' },
  { label: 'Sneakers', url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80' },
  { label: 'Sunglasses', url: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&auto=format&fit=crop&q=80' },
];

export const AdminInventory: React.FC = () => {
  const { products, categories, settings, addProduct, updateProduct, deleteProduct, adjustStock } =
    useStore();

  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('all');
  const [filterStock, setFilterStock] = useState('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState<number>(0);
  const [originalPrice, setOriginalPrice] = useState<number | undefined>(undefined);
  const [category, setCategory] = useState(categories[0]?.id || 'electronics');
  const [stock, setStock] = useState<number>(10);
  const [sku, setSku] = useState('');
  const [image, setImage] = useState('');
  const [badge, setBadge] = useState<any>('New');

  const openAddModal = () => {
    setEditingProduct(null);
    setName('');
    setDescription('');
    setPrice(5000);
    setOriginalPrice(6500);
    setCategory(categories[0]?.id || 'electronics');
    setStock(15);
    setSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
    setImage(CURATED_IMAGES[0].url);
    setBadge('New');
    setIsModalOpen(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setName(product.name);
    setDescription(product.description);
    setPrice(product.price);
    setOriginalPrice(product.originalPrice);
    setCategory(product.category);
    setStock(product.stock);
    setSku(product.sku);
    setImage(product.image);
    setBadge(product.badge || 'New');
    setIsModalOpen(true);
  };

  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !description.trim() || !image.trim()) {
      alert('Please fill in product name, description, and provide a product photo.');
      return;
    }

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name,
        description,
        price,
        originalPrice: originalPrice ? Number(originalPrice) : undefined,
        category,
        stock,
        sku,
        image,
        badge,
      });
    } else {
      addProduct({
        name,
        description,
        price,
        originalPrice: originalPrice ? Number(originalPrice) : undefined,
        category,
        stock,
        sku,
        image,
        badge,
        rating: 4.8,
        reviewsCount: 1,
        featured: true,
      });
    }

    setIsModalOpen(false);
  };

  const handleDelete = (id: string, prodName: string) => {
    if (window.confirm(`Are you sure you want to permanently delete "${prodName}" from inventory?`)) {
      deleteProduct(id);
    }
  };

  // Filtered products
  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase());
    const matchesCat = filterCat === 'all' || p.category === filterCat;
    const matchesStock =
      filterStock === 'all' ||
      (filterStock === 'low' && p.stock <= 5 && p.stock > 0) ||
      (filterStock === 'out' && p.stock === 0) ||
      (filterStock === 'in' && p.stock > 5);

    return matchesSearch && matchesCat && matchesStock;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <Package className="w-5 h-5 text-indigo-600" />
            <span>Inventory Management System</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Add new products with photos & rich descriptions, adjust stock levels, and edit details.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-extrabold px-5 py-2.5 rounded-xl shadow-md shadow-indigo-500/20 active:scale-95 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by title, SKU, description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
          />
        </div>

        {/* Category filter */}
        <select
          value={filterCat}
          onChange={(e) => setFilterCat(e.target.value)}
          className="px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-hidden"
        >
          <option value="all">All Categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>

        {/* Stock status filter */}
        <select
          value={filterStock}
          onChange={(e) => setFilterStock(e.target.value)}
          className="px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-hidden"
        >
          <option value="all">All Stock Levels</option>
          <option value="low">⚠️ Low Stock (&le; 5 units)</option>
          <option value="out">❌ Out of Stock (0 units)</option>
          <option value="in">✅ In Stock (&gt; 5 units)</option>
        </select>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Product & Image</th>
                <th className="py-3.5 px-3">Category / SKU</th>
                <th className="py-3.5 px-3">Price</th>
                <th className="py-3.5 px-3">Stock Level & Quick Adjust</th>
                <th className="py-3.5 px-3">Badge</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-slate-400">
                    No products matched your search criteria.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Image & Title */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={p.image}
                          alt={p.name}
                          className="w-12 h-12 object-cover rounded-xl border border-slate-200 shrink-0 bg-slate-100"
                        />
                        <div className="max-w-xs">
                          <p className="font-extrabold text-slate-900 text-xs sm:text-sm line-clamp-1">
                            {p.name}
                          </p>
                          <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                            {p.description}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Category / SKU */}
                    <td className="py-3.5 px-3">
                      <span className="font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded text-[11px] uppercase">
                        {p.category}
                      </span>
                      <p className="font-mono text-slate-400 text-[10px] mt-1">{p.sku}</p>
                    </td>

                    {/* Price */}
                    <td className="py-3.5 px-3">
                      <p className="font-black text-slate-900 font-mono text-xs sm:text-sm">
                        {settings.currency}{p.price.toLocaleString()}
                      </p>
                      {p.originalPrice && (
                        <p className="text-[10px] text-slate-400 line-through">
                          {settings.currency}{p.originalPrice.toLocaleString()}
                        </p>
                      )}
                    </td>

                    {/* Stock level & Quick Adjust buttons */}
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-black font-mono text-xs px-2 py-0.5 rounded-full ${
                            p.stock <= 0
                              ? 'bg-rose-100 text-rose-700'
                              : p.stock <= 5
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {p.stock} units
                        </span>

                        <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                          <button
                            type="button"
                            onClick={() => adjustStock(p.id, -1)}
                            className="px-2 py-0.5 hover:bg-slate-200 text-slate-600 font-bold"
                            title="Decrease stock"
                          >
                            -
                          </button>
                          <button
                            type="button"
                            onClick={() => adjustStock(p.id, 1)}
                            className="px-2 py-0.5 hover:bg-slate-200 text-slate-600 font-bold"
                            title="Increase stock"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </td>

                    {/* Badge */}
                    <td className="py-3.5 px-3">
                      {p.badge ? (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                          {p.badge}
                        </span>
                      ) : (
                        <span className="text-slate-300">-</span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEditModal(p)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                          title="Edit product"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(p.id, p.name)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Delete product"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 relative my-6">
            {/* Modal Header */}
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <Package className="w-5 h-5 text-indigo-400" />
                <h3 className="font-extrabold text-base">
                  {editingProduct ? 'Edit Inventory Item' : 'Add New Item to Inventory'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Form */}
            <form onSubmit={handleSaveProduct} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Product Name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Product Title / Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Wireless Ergonomic Gaming Mouse"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden font-bold"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Category <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden font-semibold capitalize"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Badge */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Badge Highlight
                  </label>
                  <select
                    value={badge}
                    onChange={(e) => setBadge(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                  >
                    <option value="">None</option>
                    <option value="Hot">🔥 Hot</option>
                    <option value="Sale">🏷️ Sale</option>
                    <option value="New">✨ New Arrival</option>
                    <option value="Popular">⭐ Popular</option>
                    <option value="Best Seller">👑 Best Seller</option>
                  </select>
                </div>

                {/* Price */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Selling Price ({settings.currency}) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden font-mono font-bold"
                  />
                </div>

                {/* Original Price */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Original Price ({settings.currency}) <span className="text-slate-400 font-normal">(for discount %)</span>
                  </label>
                  <input
                    type="number"
                    min={0}
                    placeholder="e.g. 7500"
                    value={originalPrice || ''}
                    onChange={(e) =>
                      setOriginalPrice(e.target.value ? Number(e.target.value) : undefined)
                    }
                    className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden font-mono"
                  />
                </div>

                {/* Stock Units */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Stock Quantity Units <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={stock}
                    onChange={(e) => setStock(Number(e.target.value))}
                    className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden font-mono font-bold"
                  />
                </div>

                {/* SKU */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    SKU / Product Code
                  </label>
                  <input
                    type="text"
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden font-mono"
                  />
                </div>

                {/* PHOTO SELECTION & UPLOAD */}
                <div className="sm:col-span-2 space-y-2">
                  <label className="block text-xs font-bold text-slate-700">
                    Product Photo / Image <span className="text-rose-500">*</span>
                  </label>

                  <div className="flex gap-2">
                    <input
                      type="url"
                      placeholder="Paste Image URL..."
                      value={image}
                      onChange={(e) => setImage(e.target.value)}
                      className="flex-1 px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                    />

                    {/* Local File Upload Button */}
                    <label className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer border border-slate-300 transition-colors">
                      <Upload className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Upload File</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* Curated Quick Presets */}
                  <div>
                    <span className="text-[10px] text-slate-400 font-semibold uppercase block mb-1">
                      Or pick from curated catalog photos:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {CURATED_IMAGES.map((c, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setImage(c.url)}
                          className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all ${
                            image === c.url
                              ? 'bg-indigo-600 text-white border-indigo-600 font-bold'
                              : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {c.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Photo Preview */}
                  {image && (
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <img
                        src={image}
                        alt="Product preview"
                        className="w-16 h-16 object-cover rounded-lg border border-slate-300"
                      />
                      <div className="text-xs">
                        <p className="font-bold text-slate-800">Photo Preview</p>
                        <p className="text-[11px] text-slate-500 truncate max-w-sm">{image}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Rich Description */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Product Description <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Enter detailed description, key specifications, dimensions, warranty, and features..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden resize-none"
                  />
                </div>
              </div>

              {/* Modal Footer */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl shadow-md transition-all cursor-pointer"
                >
                  {editingProduct ? 'Save Product Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
