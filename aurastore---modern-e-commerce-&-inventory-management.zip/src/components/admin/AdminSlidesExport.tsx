import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  AlertCircle,
  Presentation,
  Package,
  Layers,
  LogOut,
  User as UserIcon,
} from 'lucide-react';
import { User } from 'firebase/auth';
import { initAuth, googleSignIn, logout } from '../../services/firebaseAuth';
import { exportCatalogToGoogleSlides, SlideExportResult } from '../../services/googleSlidesService';
import { useStore } from '../../context/StoreContext';

export const AdminSlidesExport: React.FC = () => {
  const { settings, products } = useStore();

  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportResult, setExportResult] = useState<SlideExportResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, accessToken) => {
        setUser(currentUser);
        setToken(accessToken);
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    setIsSigningIn(true);
    setErrorMsg(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setToken(res.accessToken);
      }
    } catch (err: any) {
      console.error('Google Sign In error:', err);
      setErrorMsg(err?.message || 'Failed to authenticate with Google.');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await logout();
    setUser(null);
    setToken(null);
    setExportResult(null);
  };

  const handleExport = async () => {
    setErrorMsg(null);

    // Explicit confirmation required by Google Workspace Skill
    const confirmed = window.confirm(
      `Create a new Google Slides presentation deck featuring ${Math.min(products.length, 8)} products from "${settings.storeName}" in your Google Drive?`
    );
    if (!confirmed) return;

    setIsExporting(true);
    try {
      const result = await exportCatalogToGoogleSlides(
        settings.storeName,
        settings.tagline,
        products
      );
      setExportResult(result);
    } catch (err: any) {
      console.error('Export error:', err);
      setErrorMsg(err?.message || 'Failed to export catalog to Google Slides.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <Presentation className="w-5 h-5 text-amber-500" />
            <span>Google Slides Catalog Integration</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Export store inventory and marketing presentation decks directly to your Google Slides account.
          </p>
        </div>

        {user && (
          <div className="flex items-center gap-3 bg-slate-50 px-3.5 py-1.5 rounded-xl border border-slate-200 text-xs">
            <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold">
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName || 'Google User'} className="w-full h-full rounded-full" />
              ) : (
                <UserIcon className="w-4 h-4" />
              )}
            </div>
            <div className="hidden sm:block text-left">
              <p className="font-bold text-slate-800">{user.displayName || 'Google Connected'}</p>
              <p className="text-[10px] text-slate-500 truncate max-w-[140px]">{user.email}</p>
            </div>
            <button
              onClick={handleSignOut}
              className="p-1 hover:bg-slate-200 rounded text-slate-500"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4 text-rose-500" />
            </button>
          </div>
        )}
      </div>

      {errorMsg && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-semibold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Integration Card */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        {!user ? (
          /* Sign In with Google Prompt */
          <div className="max-w-md mx-auto text-center space-y-5 py-6">
            <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 mx-auto flex items-center justify-center shadow-inner">
              <Presentation className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900">
                Connect Your Google Account
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                Authorize Google Slides to create high-resolution product catalog decks, sales
                presentations, and wholesale brochures directly from your current inventory.
              </p>
            </div>

            {/* Official Google Material Sign-In Button */}
            <div className="flex justify-center">
              <button
                type="button"
                onClick={handleSignIn}
                disabled={isSigningIn}
                className="inline-flex items-center gap-3 px-5 py-3 rounded-full border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-bold text-sm shadow-md hover:shadow-lg transition-all active:scale-95 cursor-pointer disabled:opacity-60"
              >
                <svg className="w-5 h-5" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </svg>
                <span>{isSigningIn ? 'Connecting to Google...' : 'Sign in with Google'}</span>
              </button>
            </div>
          </div>
        ) : (
          /* Authenticated: Export Action Section */
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-gradient-to-r from-amber-50 via-orange-50 to-indigo-50 rounded-2xl border border-amber-200">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-amber-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  Ready to Export
                </span>
                <h3 className="font-extrabold text-base text-slate-900">
                  Generate Presentation for "{settings.storeName}"
                </h3>
                <p className="text-xs text-slate-600">
                  Includes title cover slide and slides for {Math.min(products.length, 8)} active products with images, prices, and descriptions.
                </p>
              </div>

              <button
                onClick={handleExport}
                disabled={isExporting}
                className="flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-extrabold px-6 py-3 rounded-xl shadow-lg shadow-orange-500/25 active:scale-95 transition-all text-xs sm:text-sm cursor-pointer disabled:opacity-60"
              >
                {isExporting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Generating Presentation...</span>
                  </>
                ) : (
                  <>
                    <Presentation className="w-4 h-4" />
                    <span>Export to Google Slides</span>
                  </>
                )}
              </button>
            </div>

            {/* Export Success Result Card */}
            {exportResult && (
              <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-4 animate-fadeIn">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-black text-emerald-950 text-base">
                        Google Slides Deck Created Successfully!
                      </h4>
                      <p className="text-xs text-emerald-800 mt-0.5 font-medium">
                        "{exportResult.title}" has been saved to your Google Drive.
                      </p>
                    </div>
                  </div>

                  <a
                    href={exportResult.presentationUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-md transition-all shrink-0"
                  >
                    <span>Open in Google Slides</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                <div className="p-3 bg-white/80 rounded-xl border border-emerald-200 text-xs text-slate-700 space-y-1">
                  <p className="font-bold">Presentation ID: <span className="font-mono text-slate-500 font-normal">{exportResult.presentationId}</span></p>
                  <p className="text-[11px] text-slate-500">
                    You can view, edit, share, or present these product slides directly using your Google Slides workspace.
                  </p>
                </div>
              </div>
            )}

            {/* Preview of Deck Structure */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Included Products Preview ({Math.min(products.length, 8)} Slides)
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {products.slice(0, 4).map((p) => (
                  <div key={p.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center gap-2.5 text-xs">
                    <img src={p.image} alt={p.name} className="w-10 h-10 object-cover rounded-lg border border-slate-200 shrink-0" />
                    <div className="truncate">
                      <p className="font-bold text-slate-900 truncate">{p.name}</p>
                      <p className="text-[11px] text-slate-500 font-mono">{settings.currency}{p.price.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
