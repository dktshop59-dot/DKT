import React, { useState } from 'react';
import {
  ShoppingBag,
  CheckCircle2,
  Clock,
  Eye,
  Check,
  X,
  Printer,
  Truck,
  CreditCard,
  Building2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { Order, OrderStatus, PaymentStatus } from '../../types/store';

export const AdminOrders: React.FC = () => {
  const { orders, settings, updateOrderStatus } = useStore();

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [viewingSlipUrl, setViewingSlipUrl] = useState<string | null>(null);

  const filteredOrders = orders.filter((o) => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'pending_verification') return o.paymentStatus === 'pending_verification';
    return o.orderStatus === filterStatus;
  });

  const handleVerifyBankPayment = (orderId: string) => {
    updateOrderStatus(orderId, 'processing', 'paid');
    if (selectedOrder?.id === orderId) {
      setSelectedOrder((prev) => (prev ? { ...prev, paymentStatus: 'paid', orderStatus: 'processing' } : null));
    }
  };

  const handleUpdateStatus = (orderId: string, status: OrderStatus) => {
    updateOrderStatus(orderId, status);
    if (selectedOrder?.id === orderId) {
      setSelectedOrder((prev) => (prev ? { ...prev, orderStatus: status } : null));
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-indigo-600" />
            <span>Orders & Payment Verification</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Review customer purchases, inspect bank deposit slips, and update dispatch tracking.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'all', label: 'All' },
            { id: 'pending_verification', label: '⚠️ Needs Slip Review' },
            { id: 'processing', label: 'Processing' },
            { id: 'shipped', label: 'Shipped' },
            { id: 'delivered', label: 'Delivered' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterStatus === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Orders List Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Order ID & Date</th>
                <th className="py-3.5 px-3">Customer Details</th>
                <th className="py-3.5 px-3">Payment Method & Slip</th>
                <th className="py-3.5 px-3">Payment Status</th>
                <th className="py-3.5 px-3">Fulfillment Status</th>
                <th className="py-3.5 px-3 text-right">Total</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    No orders found matching the filter.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Order ID & Date */}
                    <td className="py-3.5 px-4">
                      <p className="font-extrabold text-slate-900 font-mono text-sm">{order.id}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </p>
                    </td>

                    {/* Customer */}
                    <td className="py-3.5 px-3">
                      <p className="font-bold text-slate-900">{order.customerName}</p>
                      <p className="text-slate-500 text-[11px]">{order.customerPhone}</p>
                      <p className="text-slate-400 text-[10px] truncate max-w-[150px]">
                        {order.city}
                      </p>
                    </td>

                    {/* Payment Method & Slip */}
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-1.5 font-semibold text-slate-700 capitalize">
                        {order.paymentMethod === 'bank_transfer' ? (
                          <Building2 className="w-3.5 h-3.5 text-indigo-600" />
                        ) : order.paymentMethod === 'card' ? (
                          <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Truck className="w-3.5 h-3.5 text-amber-600" />
                        )}
                        <span>{order.paymentMethod.replace('_', ' ')}</span>
                      </div>

                      {order.bankSlipUrl ? (
                        <button
                          onClick={() => setViewingSlipUrl(order.bankSlipUrl!)}
                          className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded hover:bg-indigo-100 transition-colors"
                        >
                          <Eye className="w-3 h-3" /> View Deposit Slip
                        </button>
                      ) : order.bankTransferRef ? (
                        <span className="font-mono text-[10px] text-slate-500 block mt-0.5">
                          Ref: {order.bankTransferRef}
                        </span>
                      ) : null}
                    </td>

                    {/* Payment Status */}
                    <td className="py-3.5 px-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-extrabold capitalize ${
                          order.paymentStatus === 'paid'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : order.paymentStatus === 'pending_verification'
                            ? 'bg-amber-50 text-amber-800 border border-amber-300'
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                        }`}
                      >
                        {order.paymentStatus === 'paid' ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <Clock className="w-3 h-3 text-amber-600" />
                        )}
                        <span>{order.paymentStatus.replace('_', ' ')}</span>
                      </span>
                    </td>

                    {/* Fulfillment Status */}
                    <td className="py-3.5 px-3">
                      <select
                        value={order.orderStatus}
                        onChange={(e) => handleUpdateStatus(order.id, e.target.value as OrderStatus)}
                        className="px-2.5 py-1 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg focus:outline-hidden"
                      >
                        <option value="pending">Pending</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </td>

                    {/* Total */}
                    <td className="py-3.5 px-3 text-right">
                      <p className="font-black text-slate-900 font-mono text-sm">
                        {settings.currency}{order.total.toLocaleString()}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {order.items.reduce((s, i) => s + i.quantity, 0)} items
                      </p>
                    </td>

                    {/* Action buttons */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {order.paymentStatus === 'pending_verification' && (
                          <button
                            onClick={() => handleVerifyBankPayment(order.id)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] px-2.5 py-1 rounded-lg shadow-xs flex items-center gap-1 transition-all"
                            title="Verify bank deposit slip"
                          >
                            <Check className="w-3 h-3" />
                            <span>Verify Slip</span>
                          </button>
                        )}

                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                          title="View order invoice & details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bank Slip Lightbox Modal */}
      {viewingSlipUrl && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-600" />
                Customer Uploaded Bank Slip
              </h4>
              <button
                onClick={() => setViewingSlipUrl(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center max-h-[500px]">
              <img
                src={viewingSlipUrl}
                alt="Bank deposit slip receipt"
                className="w-full h-auto object-contain"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setViewingSlipUrl(null)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Order Details & Invoice Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <span className="text-xs font-mono font-bold text-indigo-600 uppercase">
                  Invoice & Packing Slip
                </span>
                <h3 className="text-xl font-black text-slate-900">{selectedOrder.id}</h3>
                <p className="text-xs text-slate-500">
                  Placed on {new Date(selectedOrder.createdAt).toLocaleString()}
                </p>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Customer Details */}
            <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-2xl">
              <div>
                <p className="text-slate-400 font-bold uppercase text-[10px]">Customer</p>
                <p className="font-extrabold text-slate-800 text-sm mt-0.5">
                  {selectedOrder.customerName}
                </p>
                <p className="text-slate-500 mt-1">{selectedOrder.customerPhone}</p>
                <p className="text-slate-500">{selectedOrder.customerEmail}</p>
              </div>
              <div>
                <p className="text-slate-400 font-bold uppercase text-[10px]">Shipping Address</p>
                <p className="font-semibold text-slate-800 mt-0.5">
                  {selectedOrder.shippingAddress}
                </p>
                <p className="text-slate-500">{selectedOrder.city} {selectedOrder.postalCode}</p>
                {selectedOrder.notes && (
                  <p className="text-[11px] text-amber-800 mt-1 bg-amber-50 p-1.5 rounded">
                    Notes: {selectedOrder.notes}
                  </p>
                )}
              </div>
            </div>

            {/* Items */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Order Items
              </h4>
              <div className="border border-slate-100 rounded-xl divide-y divide-slate-100 overflow-hidden text-xs">
                {selectedOrder.items.map((item, i) => (
                  <div key={i} className="p-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-10 h-10 object-cover rounded-lg border border-slate-200"
                      />
                      <div>
                        <p className="font-bold text-slate-900">{item.product.name}</p>
                        <p className="text-slate-500 text-[11px]">
                          {item.quantity} × {settings.currency}{item.product.price.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <span className="font-black text-slate-900 font-mono">
                      {settings.currency}{(item.product.price * item.quantity).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Total */}
            <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-sm">
              <span className="font-bold text-slate-600">Grand Total</span>
              <span className="font-black text-indigo-600 text-lg font-mono">
                {settings.currency}{selectedOrder.total.toLocaleString()}
              </span>
            </div>

            {/* Footer Buttons */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => window.print()}
                className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50"
              >
                <Printer className="w-4 h-4" />
                <span>Print Packing Slip</span>
              </button>

              <div className="flex items-center gap-2">
                {selectedOrder.paymentStatus === 'pending_verification' && (
                  <button
                    onClick={() => handleVerifyBankPayment(selectedOrder.id)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs"
                  >
                    Verify & Mark Paid
                  </button>
                )}
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
