import React from 'react';
import {
  DollarSign,
  ShoppingBag,
  Package,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  Plus,
  Building2,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';

interface AdminOverviewProps {
  onNavigateTab: (tab: 'overview' | 'settings' | 'inventory' | 'bank_accounts' | 'orders' | 'slides') => void;
  onOpenAddProduct: () => void;
}

export const AdminOverview: React.FC<AdminOverviewProps> = ({ onNavigateTab, onOpenAddProduct }) => {
  const { products, orders, settings, bankAccounts } = useStore();

  const totalRevenue = orders
    .filter((o) => o.paymentStatus === 'paid')
    .reduce((sum, o) => sum + o.total, 0);

  const lowStockProducts = products.filter((p) => p.stock <= 5);
  const pendingOrders = orders.filter(
    (o) => o.paymentStatus === 'pending_verification' || o.orderStatus === 'pending'
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-indigo-900 text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl border border-slate-800">
        <div className="absolute right-0 top-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold text-indigo-300 backdrop-blur-xs">
              <span>Admin Management Hub</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome to {settings.storeName}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Manage your store name, branding, bank accounts, inventory, customer orders, and Google Slides product catalog all in one place.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenAddProduct}
              className="flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl shadow-md active:scale-95 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Item</span>
            </button>

            <button
              onClick={() => onNavigateTab('settings')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-semibold border border-white/10 transition-colors cursor-pointer"
            >
              Store Customizer
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Metric 1: Total Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Total Revenue
            </span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl sm:text-2xl font-black text-slate-900">
              {settings.currency}{totalRevenue.toLocaleString()}
            </span>
            <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">
              Verified orders revenue
            </p>
          </div>
        </div>

        {/* Metric 2: Total Orders */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Total Orders
            </span>
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl sm:text-2xl font-black text-slate-900">
              {orders.length}
            </span>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              {pendingOrders.length} pending action
            </p>
          </div>
        </div>

        {/* Metric 3: Active Products */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Active Inventory
            </span>
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl sm:text-2xl font-black text-slate-900">
              {products.length} Products
            </span>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              {products.reduce((acc, p) => acc + p.stock, 0)} total units in stock
            </p>
          </div>
        </div>

        {/* Metric 4: Low Stock Alerts */}
        <div
          onClick={() => onNavigateTab('inventory')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer shadow-xs ${
            lowStockProducts.length > 0
              ? 'bg-amber-50/70 border-amber-200 text-amber-900 hover:bg-amber-100/70'
              : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
              Low Stock Alert
            </span>
            <div className="p-2 rounded-xl bg-amber-100 text-amber-700">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl sm:text-2xl font-black text-amber-950">
              {lowStockProducts.length} Items
            </span>
            <p className="text-[11px] text-amber-700 font-semibold mt-0.5">
              Click to restock inventory
            </p>
          </div>
        </div>
      </div>

      {/* Quick Action Shortcuts */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div
          onClick={() => onNavigateTab('settings')}
          className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <ArrowUpRight className="w-5 h-5" />
            </div>
            <span className="text-xs text-indigo-600 font-bold">Customize</span>
          </div>
          <h4 className="font-extrabold text-slate-900 text-sm">Store Name & Branding</h4>
          <p className="text-xs text-slate-500 mt-1">
            Change store name, announcement bar, currency, contact hotline, and theme colors.
          </p>
        </div>

        <div
          onClick={() => onNavigateTab('bank_accounts')}
          className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Building2 className="w-5 h-5" />
            </div>
            <span className="text-xs text-emerald-600 font-bold">{bankAccounts.length} Configured</span>
          </div>
          <h4 className="font-extrabold text-slate-900 text-sm">Bank Accounts Management</h4>
          <p className="text-xs text-slate-500 mt-1">
            Add or update bank accounts that customers see during direct bank transfer checkout.
          </p>
        </div>

        <div
          onClick={() => onNavigateTab('slides')}
          className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <span className="text-xs text-amber-600 font-bold">Workspace</span>
          </div>
          <h4 className="font-extrabold text-slate-900 text-sm">Google Slides Catalog</h4>
          <p className="text-xs text-slate-500 mt-1">
            Export store inventory and marketing presentation decks directly to Google Slides.
          </p>
        </div>
      </div>

      {/* Recent Orders Overview */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
              Recent Customer Orders
            </h3>
            <p className="text-xs text-slate-500">Incoming purchases and payment statuses</p>
          </div>
          <button
            onClick={() => onNavigateTab('orders')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors"
          >
            View All ({orders.length}) →
          </button>
        </div>

        <div className="divide-y divide-slate-100 overflow-x-auto">
          {orders.slice(0, 4).map((order) => (
            <div key={order.id} className="p-4 flex items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center font-bold text-slate-700">
                  {order.id.slice(-3)}
                </div>
                <div>
                  <p className="font-bold text-slate-900">{order.customerName}</p>
                  <p className="text-slate-400 font-mono text-[11px]">{order.id} • {order.city}</p>
                </div>
              </div>

              <div className="hidden sm:block">
                <p className="font-semibold text-slate-700">{order.items.length} items</p>
                <p className="text-slate-400 text-[11px]">
                  {order.paymentMethod === 'bank_transfer'
                    ? 'Direct Bank Transfer'
                    : order.paymentMethod === 'card'
                    ? 'Card Payment'
                    : 'Cash On Delivery'}
                </p>
              </div>

              <div>
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                    order.paymentStatus === 'paid'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : order.paymentStatus === 'pending_verification'
                      ? 'bg-amber-50 text-amber-700 border border-amber-200'
                      : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                  }`}
                >
                  {order.paymentStatus === 'paid' ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  ) : (
                    <Clock className="w-3 h-3 text-amber-600" />
                  )}
                  <span className="capitalize">{order.paymentStatus.replace('_', ' ')}</span>
                </span>
              </div>

              <div className="text-right">
                <p className="font-black text-slate-900 font-mono">
                  {settings.currency}{order.total.toLocaleString()}
                </p>
                <p className="text-[10px] text-slate-400">
                  {new Date(order.createdAt).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
