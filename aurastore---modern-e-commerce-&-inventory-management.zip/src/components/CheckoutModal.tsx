import React, { useState } from 'react';
import {
  X,
  CreditCard,
  Building2,
  Truck,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Check,
  Upload,
  AlertCircle,
  Lock,
  ArrowRight,
  Smartphone,
  Info,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useStore } from '../context/StoreContext';
import { BankAccount, PaymentMethod } from '../types/store';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    cartTotal,
    settings,
    bankAccounts,
    placeOrder,
  } = useStore();

  // Form Fields
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [city, setCity] = useState('Colombo');
  const [postalCode, setPostalCode] = useState('');
  const [notes, setNotes] = useState('');

  // Payment Selection
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');

  // Card Payment State
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardFlipped, setCardFlipped] = useState(false);

  // Bank Transfer State
  const activeBankAccounts = bankAccounts.filter((b) => b.isActive);
  const [selectedBankId, setSelectedBankId] = useState<string>(
    activeBankAccounts.find((b) => b.isPrimary)?.id || activeBankAccounts[0]?.id || ''
  );
  const [bankTransferRef, setBankTransferRef] = useState('');
  const [bankSlipUrl, setBankSlipUrl] = useState('');
  const [slipFileName, setSlipFileName] = useState('');
  const [copiedBankId, setCopiedBankId] = useState<string | null>(null);

  // UI state
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isCheckoutOpen) return null;

  const shippingFee = cartTotal >= settings.freeShippingThreshold ? 0 : settings.standardShippingFee;
  const orderTotal = cartTotal + shippingFee;

  // Selected Bank Object
  const selectedBank = activeBankAccounts.find((b) => b.id === selectedBankId) || activeBankAccounts[0];

  // Helper to copy account number
  const handleCopyAccount = (accNumber: string, id: string) => {
    navigator.clipboard.writeText(accNumber);
    setCopiedBankId(id);
    setTimeout(() => setCopiedBankId(null), 2500);
  };

  // Helper for Slip File Upload (converts to base64 for instant display in admin panel)
  const handleSlipUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSlipFileName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setBankSlipUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Card number formatting
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '').slice(0, 16);
    const formatted = raw.match(/.{1,4}/g)?.join(' ') || raw;
    setCardNumber(formatted);
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (raw.length >= 3) {
      setCardExpiry(`${raw.slice(0, 2)}/${raw.slice(2, 4)}`);
    } else {
      setCardExpiry(raw);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Validations
    if (!customerName.trim() || !customerPhone.trim() || !shippingAddress.trim()) {
      setErrorMsg('Please enter customer name, phone number, and delivery address.');
      return;
    }

    if (paymentMethod === 'card') {
      const rawCard = cardNumber.replace(/\s/g, '');
      if (rawCard.length < 15 || !cardExpiry || cardCvv.length < 3) {
        setErrorMsg('Please enter complete valid card details (number, expiry, CVV).');
        return;
      }
    }

    if (paymentMethod === 'bank_transfer') {
      if (!selectedBank) {
        setErrorMsg('No store bank account available. Please contact store owner.');
        return;
      }
      if (!bankSlipUrl && !bankTransferRef.trim()) {
        setErrorMsg('Please enter your Bank Transfer Reference Number or upload a deposit receipt photo.');
        return;
      }
    }

    setIsProcessing(true);

    try {
      if (paymentMethod === 'card') {
        setProcessingStep('Initiating 256-Bit SSL Handshake...');
        await new Promise((r) => setTimeout(r, 600));
        setProcessingStep('Verifying 3D Secure Cardholder Authentication...');
        await new Promise((r) => setTimeout(r, 900));
        setProcessingStep('Payment Approved! Finalizing Order...');
        await new Promise((r) => setTimeout(r, 500));
      } else if (paymentMethod === 'bank_transfer') {
        setProcessingStep('Verifying Bank Transfer Details & Uploading Slip...');
        await new Promise((r) => setTimeout(r, 900));
      } else {
        setProcessingStep('Confirming Order with Dispatch Team...');
        await new Promise((r) => setTimeout(r, 700));
      }

      // Fire confetti celebration
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (err) {
        console.warn('Confetti error:', err);
      }

      // Place order in store context
      placeOrder({
        customerName,
        customerEmail: customerEmail || 'customer@aurastore.lk',
        customerPhone,
        shippingAddress,
        city,
        postalCode: postalCode || '00100',
        paymentMethod,
        bankAccountId: paymentMethod === 'bank_transfer' ? selectedBank?.id : undefined,
        bankSlipUrl: paymentMethod === 'bank_transfer' ? bankSlipUrl : undefined,
        bankTransferRef: paymentMethod === 'bank_transfer' ? bankTransferRef : undefined,
        notes,
      });

      setIsProcessing(false);
    } catch (err) {
      setIsProcessing(false);
      setErrorMsg('Failed to process payment. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-4xl w-full overflow-hidden shadow-2xl border border-slate-100 relative my-6 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-400">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-base tracking-tight flex items-center gap-2">
                <span>Secure Checkout</span>
                <span className="text-emerald-400 text-xs font-semibold bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  SSL Encrypted
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {settings.storeName} • Instant Order Confirmation
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsCheckoutOpen(false)}
            disabled={isProcessing}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7">
          {errorMsg && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form id="checkout-form" onSubmit={handleFormSubmit} className="space-y-7">
            {/* Step 1: Customer Contact & Shipping Details */}
            <div>
              <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-bold flex items-center justify-center">
                  1
                </span>
                <h4 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">
                  Customer & Delivery Details
                </h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Full Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sanjeewa Kumara"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Mobile Phone / WhatsApp <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 077 123 4567"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Email Address <span className="text-slate-400 font-normal">(for invoice & updates)</span>
                  </label>
                  <input
                    type="email"
                    placeholder="sanjeewakumara732@gmail.com"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Delivery Address <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={2}
                    placeholder="House/Building No, Street Name, Town"
                    value={shippingAddress}
                    onChange={(e) => setShippingAddress(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    City / District
                  </label>
                  <input
                    type="text"
                    placeholder="Colombo, Kandy, Galle, Gampaha..."
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Postal Code <span className="text-slate-400 font-normal">(optional)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 00300"
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>

            {/* Step 2: Payment Method Selection */}
            <div>
              <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-bold flex items-center justify-center">
                  2
                </span>
                <h4 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">
                  Select Secure Payment Method
                </h4>
              </div>

              {/* Payment Tabs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
                {/* Option 1: Card */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-sm ring-2 ring-indigo-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-2">
                    <CreditCard
                      className={`w-5 h-5 ${paymentMethod === 'card' ? 'text-indigo-600' : 'text-slate-400'}`}
                    />
                    {paymentMethod === 'card' && (
                      <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                    )}
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Credit / Debit Card</h5>
                    <p className="text-[11px] text-slate-500">Visa, Mastercard, Amex</p>
                  </div>
                </button>

                {/* Option 2: Bank Transfer (Featured & connected to Admin Bank accounts) */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank_transfer')}
                  className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    paymentMethod === 'bank_transfer'
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-sm ring-2 ring-indigo-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-2">
                    <Building2
                      className={`w-5 h-5 ${
                        paymentMethod === 'bank_transfer' ? 'text-indigo-600' : 'text-slate-400'
                      }`}
                    />
                    {paymentMethod === 'bank_transfer' && (
                      <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                    )}
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Direct Bank Transfer</h5>
                    <p className="text-[11px] text-slate-500">Deposit + Slip Upload</p>
                  </div>
                </button>

                {/* Option 3: Cash on Delivery */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cod')}
                  className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    paymentMethod === 'cod'
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-sm ring-2 ring-indigo-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-2">
                    <Truck
                      className={`w-5 h-5 ${paymentMethod === 'cod' ? 'text-indigo-600' : 'text-slate-400'}`}
                    />
                    {paymentMethod === 'cod' && (
                      <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                    )}
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Cash on Delivery</h5>
                    <p className="text-[11px] text-slate-500">Pay when delivered</p>
                  </div>
                </button>
              </div>

              {/* PAYMENT SUB-PANEL 1: Credit / Debit Card Interactive Interface */}
              {paymentMethod === 'card' && (
                <div className="p-4 sm:p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4 animate-fadeIn">
                  {/* Visual Card Simulator */}
                  <div className="max-w-xs mx-auto p-4 rounded-2xl bg-gradient-to-tr from-slate-900 via-indigo-950 to-indigo-900 text-white shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none"></div>
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-[11px] font-mono tracking-widest text-indigo-300 uppercase">
                        Aura Secure Card
                      </span>
                      <div className="w-8 h-5 bg-amber-400/80 rounded-sm"></div>
                    </div>
                    <p className="font-mono text-base tracking-widest mb-4">
                      {cardNumber || '•••• •••• •••• ••••'}
                    </p>
                    <div className="flex justify-between items-end text-[11px]">
                      <div>
                        <p className="text-slate-400 text-[9px] uppercase">Cardholder</p>
                        <p className="font-semibold uppercase tracking-wide truncate max-w-[150px]">
                          {cardHolder || 'CUSTOMER NAME'}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-[9px] uppercase">Expires</p>
                        <p className="font-mono font-semibold">{cardExpiry || 'MM/YY'}</p>
                      </div>
                    </div>
                  </div>

                  {/* Card Form Inputs */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                    <div className="col-span-2 sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Card Number
                      </label>
                      <input
                        type="text"
                        placeholder="1234 5678 9012 3456"
                        value={cardNumber}
                        onChange={handleCardNumberChange}
                        maxLength={19}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl font-mono focus:border-indigo-500 focus:outline-hidden"
                      />
                    </div>

                    <div className="col-span-2 sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Cardholder Name
                      </label>
                      <input
                        type="text"
                        placeholder="Name on card"
                        value={cardHolder}
                        onChange={(e) => setCardHolder(e.target.value)}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl focus:border-indigo-500 focus:outline-hidden uppercase"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Expires (MM/YY)
                      </label>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        value={cardExpiry}
                        onChange={handleExpiryChange}
                        maxLength={5}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl font-mono focus:border-indigo-500 focus:outline-hidden"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        CVV / CVC
                      </label>
                      <input
                        type="password"
                        placeholder="•••"
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
                        maxLength={4}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl font-mono focus:border-indigo-500 focus:outline-hidden"
                      />
                    </div>

                    <div className="col-span-2 flex items-center gap-2 text-[11px] text-slate-500 pt-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Encrypted via 256-bit TLS. We never store raw card numbers.</span>
                    </div>
                  </div>
                </div>
              )}

              {/* PAYMENT SUB-PANEL 2: Direct Bank Transfer with Admin Bank Accounts */}
              {paymentMethod === 'bank_transfer' && (
                <div className="p-4 sm:p-5 bg-indigo-50/50 rounded-2xl border border-indigo-200/80 space-y-4 animate-fadeIn">
                  <div className="flex items-start gap-2.5">
                    <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                    <p className="text-xs text-indigo-950 font-medium">
                      Select one of our official store bank accounts below, transfer{' '}
                      <strong className="text-indigo-700 font-bold">
                        {settings.currency}{orderTotal.toLocaleString()}
                      </strong>
                      , and enter the reference number or upload your deposit slip.
                    </p>
                  </div>

                  {/* Bank Account Selector */}
                  <div className="space-y-2.5">
                    <label className="block text-xs font-bold text-slate-800">
                      Choose Store Bank Account to Deposit:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {activeBankAccounts.map((account) => (
                        <div
                          key={account.id}
                          onClick={() => setSelectedBankId(account.id)}
                          className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                            selectedBank?.id === account.id
                              ? 'bg-white border-indigo-600 shadow-sm ring-2 ring-indigo-500/20'
                              : 'bg-white/80 border-slate-200 hover:bg-white'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-xs text-slate-900">
                              {account.bankName}
                            </span>
                            {account.isPrimary && (
                              <span className="text-[10px] bg-indigo-100 text-indigo-700 font-bold px-1.5 py-0.2 rounded">
                                Primary
                              </span>
                            )}
                          </div>
                          <div className="flex items-center justify-between text-xs font-mono text-slate-700">
                            <span>{account.accountNumber}</span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleCopyAccount(account.accountNumber, account.id);
                              }}
                              className="text-indigo-600 hover:text-indigo-800 p-1 flex items-center gap-1 text-[11px] font-sans"
                            >
                              {copiedBankId === account.id ? (
                                <span className="text-emerald-600 font-bold flex items-center gap-0.5">
                                  <Check className="w-3 h-3" /> Copied!
                                </span>
                              ) : (
                                <span className="flex items-center gap-0.5 text-indigo-600">
                                  <Copy className="w-3 h-3" /> Copy
                                </span>
                              )}
                            </button>
                          </div>
                          <p className="text-[11px] text-slate-500 truncate mt-0.5">
                            {account.accountName} • {account.branch}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Selected Bank Details Card */}
                  {selectedBank && (
                    <div className="p-3.5 bg-white rounded-xl border border-indigo-100 text-xs space-y-1.5">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500 font-medium">Bank:</span>
                        <span className="font-bold text-slate-900">{selectedBank.bankName}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500 font-medium">Account No:</span>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-black text-indigo-600 text-sm">
                            {selectedBank.accountNumber}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopyAccount(selectedBank.accountNumber, 'selected')}
                            className="p-1 hover:bg-slate-100 rounded text-slate-500"
                            title="Copy Account Number"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500 font-medium">Account Name:</span>
                        <span className="font-semibold text-slate-800">{selectedBank.accountName}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500 font-medium">Branch:</span>
                        <span className="font-semibold text-slate-800">{selectedBank.branch}</span>
                      </div>
                      {selectedBank.instructions && (
                        <div className="pt-1.5 border-t border-slate-100 text-[11px] text-slate-600 italic">
                          "{selectedBank.instructions}"
                        </div>
                      )}
                    </div>
                  )}

                  {/* Verification Proof: Reference Number & Slip Photo Upload */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-1">
                        Bank Reference / Transaction ID
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. TXN-89240182 or Deposit Slip Ref"
                        value={bankTransferRef}
                        onChange={(e) => setBankTransferRef(e.target.value)}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl focus:border-indigo-500 focus:outline-hidden font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-1">
                        Upload Payment Slip Photo
                      </label>
                      <label className="flex items-center justify-center gap-2 px-3 py-2 border-2 border-dashed border-indigo-300 hover:border-indigo-500 rounded-xl bg-white cursor-pointer hover:bg-indigo-50/50 transition-colors text-xs font-semibold text-indigo-700">
                        <Upload className="w-4 h-4 text-indigo-600" />
                        <span className="truncate">
                          {slipFileName ? slipFileName : 'Choose Slip Image'}
                        </span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleSlipUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  {/* Slip Preview if uploaded */}
                  {bankSlipUrl && (
                    <div className="flex items-center gap-3 p-2.5 bg-white rounded-xl border border-emerald-200">
                      <img
                        src={bankSlipUrl}
                        alt="Bank receipt preview"
                        className="w-12 h-12 object-cover rounded-lg border border-slate-200"
                      />
                      <div className="flex-1 text-xs">
                        <p className="font-bold text-emerald-800 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Slip Attached
                        </p>
                        <p className="text-[11px] text-slate-500 truncate max-w-xs">
                          {slipFileName || 'payment-slip.jpg'}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setBankSlipUrl('');
                          setSlipFileName('');
                        }}
                        className="text-xs text-rose-500 hover:underline font-semibold"
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* PAYMENT SUB-PANEL 3: Cash On Delivery */}
              {paymentMethod === 'cod' && (
                <div className="p-4 sm:p-5 bg-amber-50/70 rounded-2xl border border-amber-200 space-y-2 animate-fadeIn">
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-amber-600" />
                    <h5 className="text-xs font-bold text-amber-950">Cash On Delivery Terms</h5>
                  </div>
                  <p className="text-xs text-amber-900 leading-relaxed">
                    You can pay the full amount of{' '}
                    <strong className="font-black text-slate-900">
                      {settings.currency}{orderTotal.toLocaleString()}
                    </strong>{' '}
                    directly in cash to the courier representative when the parcel arrives at your
                    doorstep. Our dispatch team may call your phone number ({customerPhone || '07X XXX XXXX'}) to confirm before dispatching.
                  </p>
                </div>
              )}
            </div>

            {/* Step 3: Order Summary Review */}
            <div className="p-4 sm:p-5 bg-slate-50 rounded-2xl border border-slate-200">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-3">
                Order Summary ({cart.length} items)
              </h4>
              <div className="space-y-2 max-h-36 overflow-y-auto pr-1 text-xs">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex justify-between items-center">
                    <span className="text-slate-700 truncate max-w-[240px]">
                      {item.quantity}x {item.product.name}
                    </span>
                    <span className="font-semibold text-slate-900 font-mono">
                      {settings.currency}{(item.product.price * item.quantity).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-3 mt-3 border-t border-slate-200 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span>{settings.currency}{cartTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Shipping & Handling</span>
                  <span>
                    {shippingFee === 0 ? (
                      <span className="text-emerald-600 font-bold">FREE</span>
                    ) : (
                      `${settings.currency}${shippingFee.toLocaleString()}`
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-200">
                  <span>Total Amount Due</span>
                  <span className="text-indigo-600">
                    {settings.currency}{orderTotal.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </form>
        </div>

        {/* Modal Footer CTA */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Guaranteed Safe & Secure Checkout</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => setIsCheckoutOpen(false)}
              disabled={isProcessing}
              className="px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors w-1/3 sm:w-auto cursor-pointer"
            >
              Back
            </button>

            <button
              type="submit"
              form="checkout-form"
              disabled={isProcessing}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white font-extrabold px-7 py-3 rounded-xl shadow-lg shadow-indigo-600/30 active:scale-98 transition-all text-sm cursor-pointer disabled:opacity-60"
            >
              {isProcessing ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>{processingStep || 'Processing...'}</span>
                </div>
              ) : (
                <>
                  <span>
                    Pay {settings.currency}{orderTotal.toLocaleString()}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
