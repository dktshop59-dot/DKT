import React, { useState } from 'react';
import {
  ShoppingBag,
  Heart,
  Search,
  Settings,
  Store,
  PhoneCall,
  Menu,
  X,
  Sparkles,
  ShieldCheck,
  CreditCard,
  Lock,
  Unlock,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const Navbar: React.FC = () => {
  const {
    settings,
    cartItemCount,
    wishlist,
    currentView,
    setCurrentView,
    setIsCartOpen,
    searchQuery,
    setSearchQuery,
    isAdminAuthenticated,
    openAdminPanel,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Announcement Bar */}
      {settings.showAnnouncement && settings.announcementText && (
        <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white text-xs sm:text-sm font-medium py-2 px-4 text-center flex items-center justify-center gap-2 shadow-inner">
          <Sparkles className="w-4 h-4 shrink-0 animate-pulse text-yellow-300" />
          <span className="truncate max-w-4xl tracking-wide">{settings.announcementText}</span>
          <span className="hidden md:inline-flex items-center gap-1 bg-white/20 px-2 py-0.5 rounded-full text-xs font-semibold backdrop-blur-xs">
            Islandwide Delivery
          </span>
        </div>
      )}

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Logo & Store Name */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setCurrentView('store');
              }}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-indigo-600 to-rose-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/25 group-hover:scale-105 transition-transform duration-200">
                {settings.logoUrl ? (
                  <img
                    src={settings.logoUrl}
                    alt={settings.storeName}
                    className="w-full h-full object-cover rounded-xl"
                  />
                ) : (
                  <ShoppingBag className="w-5 h-5 sm:w-6 sm:h-6" />
                )}
              </div>
              <div>
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-slate-900 group-hover:text-indigo-600 transition-colors flex items-center gap-1.5">
                  {settings.storeName}
                  <span className="hidden sm:inline-block w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                </span>
                <p className="text-xs text-slate-500 hidden sm:block truncate max-w-xs font-medium">
                  {settings.tagline}
                </p>
              </div>
            </button>
          </div>

          {/* Search Bar (Customer Store mode) */}
          {currentView === 'store' && (
            <div className="hidden md:flex flex-1 max-w-md mx-4">
              <div className="relative w-full">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search products, brands, gadgets, fashion..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-100/90 hover:bg-slate-100 focus:bg-white text-sm rounded-full border border-transparent focus:border-indigo-400 focus:ring-4 focus:ring-indigo-500/10 focus:outline-hidden transition-all placeholder:text-slate-400"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 bg-slate-200 hover:bg-slate-300 rounded-full w-4 h-4 flex items-center justify-center"
                  >
                    ×
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Right Action Icons & View Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Contact hotline */}
            {settings.phone && (
              <a
                href={`tel:${settings.phone}`}
                className="hidden lg:flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 px-3 py-2 rounded-lg hover:bg-slate-50 transition-colors"
                title="Customer Support Hotline"
              >
                <PhoneCall className="w-3.5 h-3.5 text-emerald-500" />
                <span>{settings.phone}</span>
              </a>
            )}

            {/* Wishlist */}
            {currentView === 'store' && (
              <div className="relative">
                <button
                  className="p-2 sm:p-2.5 rounded-xl text-slate-600 hover:text-rose-500 hover:bg-rose-50/70 transition-colors relative"
                  title="Wishlist"
                >
                  <Heart className={`w-5 h-5 ${wishlist.length > 0 ? 'fill-rose-500 text-rose-500' : ''}`} />
                  {wishlist.length > 0 && (
                    <span className="absolute top-1 right-1 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                      {wishlist.length}
                    </span>
                  )}
                </button>
              </div>
            )}

            {/* Cart Button */}
            {currentView === 'store' && (
              <button
                onClick={() => setIsCartOpen(true)}
                className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white px-3.5 py-2 sm:py-2.5 rounded-xl font-semibold text-sm shadow-md shadow-indigo-600/20 active:scale-95 transition-all"
              >
                <div className="relative">
                  <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />
                  {cartItemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-rose-500 text-white text-[10px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center border-2 border-indigo-700 animate-bounce">
                      {cartItemCount}
                    </span>
                  )}
                </div>
                <span className="hidden sm:inline font-bold">Cart</span>
              </button>
            )}

            {/* Admin Panel / Customer View Toggle */}
            <button
              onClick={() => {
                if (currentView === 'store') {
                  openAdminPanel();
                } else {
                  setCurrentView('store');
                }
              }}
              className={`flex items-center gap-2 px-3.5 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition-all cursor-pointer ${
                currentView === 'admin'
                  ? 'bg-slate-900 text-white border-slate-900 shadow-md shadow-slate-900/20 hover:bg-slate-800'
                  : 'bg-indigo-50/80 text-indigo-700 border-indigo-200/80 hover:bg-indigo-100/90'
              }`}
            >
              {currentView === 'admin' ? (
                <>
                  <Store className="w-4 h-4 text-emerald-400" />
                  <span>Storefront</span>
                </>
              ) : (
                <>
                  {isAdminAuthenticated ? (
                    <Settings className="w-4 h-4 text-indigo-600 animate-spin-slow" />
                  ) : (
                    <Lock className="w-4 h-4 text-indigo-600" />
                  )}
                  <span>Admin Panel</span>
                </>
              )}
            </button>

            {/* Mobile Search Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Search input dropdown */}
        {mobileMenuOpen && currentView === 'store' && (
          <div className="pb-4 pt-1 md:hidden">
            <div className="relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-100 text-sm rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>
        )}
      </div>

      {/* Security & Trust Strip for Customer confidence */}
      {currentView === 'store' && (
        <div className="bg-slate-900 text-slate-300 text-[11px] py-1 px-4 border-t border-slate-800/80 hidden sm:block">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <ShieldCheck className="w-3.5 h-3.5" /> 256-Bit SSL Encrypted Checkout
              </span>
              <span className="flex items-center gap-1 text-slate-400">
                <CreditCard className="w-3.5 h-3.5 text-indigo-400" /> Visa, Mastercard, Direct Bank Transfer & COD Supported
              </span>
            </div>
            <div className="flex items-center gap-3 text-slate-400">
              <span>Delivery Islandwide across Sri Lanka</span>
              <span>•</span>
              <span className="text-amber-400 font-semibold">100% Genuine Guarantee</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
