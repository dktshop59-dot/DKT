import React from 'react';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Truck,
  RotateCcw,
  CreditCard,
  Building2,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const HeroBanner: React.FC = () => {
  const { settings, categories, setSelectedCategory } = useStore();

  const scrollToProducts = () => {
    const el = document.getElementById('products-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-indigo-900 via-slate-900 to-slate-950 text-white py-12 sm:py-20">
      {/* Decorative colorful glow effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-10 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl pointer-events-none translate-y-1/3"></div>
      <div className="absolute top-1/2 right-1/3 w-64 h-64 bg-cyan-500/15 rounded-full blur-2xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Headlines & CTA */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {settings.heroBadge && (
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/15 backdrop-blur-md text-xs sm:text-sm font-medium text-indigo-200 shadow-inner">
                <Sparkles className="w-4 h-4 text-amber-300 animate-spin-slow" />
                <span>{settings.heroBadge}</span>
              </div>
            )}

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight sm:leading-none">
              <span className="block bg-gradient-to-r from-white via-slate-100 to-indigo-200 bg-clip-text text-transparent">
                {settings.heroTitle}
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
              {settings.heroSubtitle}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={scrollToProducts}
                className="flex items-center gap-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:from-indigo-600 hover:to-pink-600 text-white font-bold px-7 py-3.5 rounded-xl shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 hover:scale-105 active:scale-95 transition-all text-sm sm:text-base cursor-pointer"
              >
                <span>Shop Featured Collection</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2 text-xs text-slate-300 bg-white/5 border border-white/10 px-4 py-3 rounded-xl backdrop-blur-sm">
                <Building2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Direct Bank Transfer & Verified Bank Slips</span>
              </div>
            </div>

            {/* Quick Category Badges */}
            <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-2">
              <span className="text-xs text-slate-400 mr-1 font-semibold uppercase tracking-wider">
                Trending:
              </span>
              {categories.slice(0, 4).map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    scrollToProducts();
                  }}
                  className="text-xs bg-slate-800/80 hover:bg-indigo-600/40 text-slate-300 hover:text-white px-3 py-1.5 rounded-full border border-slate-700 transition-colors"
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Hero Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10 aspect-4/3 group">
                <img
                  src={
                    settings.heroImage ||
                    'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&auto=format&fit=crop&q=80'
                  }
                  alt={settings.storeName}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>

                {/* Floating mini stats badge */}
                <div className="absolute bottom-4 left-4 right-4 bg-slate-900/90 backdrop-blur-md p-3.5 rounded-xl border border-white/15 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-400 font-medium">Free Delivery Above</p>
                    <p className="text-base font-extrabold text-emerald-400">
                      {settings.currency} {settings.freeShippingThreshold.toLocaleString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-slate-400 font-medium">Support Hotline</p>
                    <p className="text-xs font-semibold text-white">{settings.phone}</p>
                  </div>
                </div>
              </div>

              {/* Floating aesthetic pill */}
              <div className="absolute -top-4 -right-4 hidden sm:flex items-center gap-2 bg-gradient-to-r from-amber-500 to-rose-500 text-white font-extrabold text-xs px-3.5 py-1.5 rounded-full shadow-lg shadow-rose-500/25 animate-bounce">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Special Offers Inside</span>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Highlights Grid */}
        <div className="mt-14 pt-8 border-t border-white/10 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 text-slate-300">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5 backdrop-blur-xs">
            <div className="p-2.5 rounded-lg bg-indigo-500/20 text-indigo-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">Express Delivery</p>
              <p className="text-[11px] text-slate-400">Safe islandwide courier</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5 backdrop-blur-xs">
            <div className="p-2.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">Secure Checkout</p>
              <p className="text-[11px] text-slate-400">Card & Bank Transfer</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5 backdrop-blur-xs">
            <div className="p-2.5 rounded-lg bg-pink-500/20 text-pink-400">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">Easy Returns</p>
              <p className="text-[11px] text-slate-400">7-Day replacement guarantee</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5 backdrop-blur-xs">
            <div className="p-2.5 rounded-lg bg-amber-500/20 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">100% Authentic</p>
              <p className="text-[11px] text-slate-400">Official manufacturer warranty</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
