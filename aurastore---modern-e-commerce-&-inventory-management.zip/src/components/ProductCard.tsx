import React from 'react';
import {
  Heart,
  Eye,
  Plus,
  Star,
  Check,
  AlertCircle,
  ShoppingBag,
} from 'lucide-react';
import { Product } from '../types/store';
import { useStore } from '../context/StoreContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    settings,
    addToCart,
    toggleWishlist,
    isWishlisted,
    setViewingProduct,
  } = useStore();

  const wishlisted = isWishlisted(product.id);
  const discountPercent =
    product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null;

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/90 hover:border-indigo-300 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden relative">
      {/* Badges Overlay */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 items-start">
        {product.badge && (
          <span
            className={`text-[11px] font-extrabold uppercase px-2.5 py-0.5 rounded-full shadow-xs ${
              product.badge === 'Hot'
                ? 'bg-rose-500 text-white'
                : product.badge === 'Sale'
                ? 'bg-amber-500 text-white'
                : product.badge === 'New'
                ? 'bg-emerald-500 text-white'
                : 'bg-indigo-600 text-white'
            }`}
          >
            {product.badge}
          </span>
        )}
        {discountPercent && (
          <span className="text-[11px] font-black bg-rose-600/90 text-white px-2 py-0.5 rounded-md shadow-xs">
            -{discountPercent}%
          </span>
        )}
      </div>

      {/* Wishlist Button */}
      <button
        onClick={() => toggleWishlist(product.id)}
        className="absolute top-3 right-3 z-10 p-2 rounded-full bg-white/90 backdrop-blur-md shadow-md hover:bg-white text-slate-500 hover:text-rose-500 transition-all active:scale-90"
        title="Add to wishlist"
      >
        <Heart
          className={`w-4 h-4 ${wishlisted ? 'fill-rose-500 text-rose-500' : ''}`}
        />
      </button>

      {/* Product Image */}
      <div
        onClick={() => setViewingProduct(product)}
        className="relative w-full aspect-square bg-slate-100 overflow-hidden cursor-pointer"
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Quick View Hover Overlay */}
        <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-4">
          <span className="bg-white/95 backdrop-blur-md text-slate-900 text-xs font-bold px-3.5 py-2 rounded-xl shadow-lg flex items-center gap-1.5 hover:bg-indigo-600 hover:text-white transition-colors">
            <Eye className="w-3.5 h-3.5" />
            Quick View
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Stock Indicator */}
          <div className="flex items-center justify-between gap-2 mb-1.5 text-xs">
            <span className="font-semibold text-indigo-600 uppercase tracking-wider text-[11px]">
              {product.category}
            </span>
            {product.stock <= 0 ? (
              <span className="flex items-center gap-1 text-rose-600 font-semibold text-[11px]">
                <AlertCircle className="w-3 h-3" /> Out of Stock
              </span>
            ) : product.stock <= 5 ? (
              <span className="flex items-center gap-1 text-amber-600 font-semibold text-[11px] bg-amber-50 px-1.5 py-0.5 rounded">
                <AlertCircle className="w-3 h-3" /> Only {product.stock} left!
              </span>
            ) : (
              <span className="flex items-center gap-1 text-emerald-600 font-semibold text-[11px]">
                <Check className="w-3 h-3" /> In Stock ({product.stock})
              </span>
            )}
          </div>

          {/* Product Name */}
          <h3
            onClick={() => setViewingProduct(product)}
            className="font-bold text-slate-900 group-hover:text-indigo-600 text-sm sm:text-base leading-snug line-clamp-2 cursor-pointer transition-colors"
          >
            {product.name}
          </h3>

          {/* Description snippet */}
          <p className="text-xs text-slate-500 line-clamp-2 mt-1.5 leading-relaxed">
            {product.description}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-2.5">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < Math.floor(product.rating)
                      ? 'fill-amber-400 text-amber-400'
                      : 'text-slate-200'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs font-bold text-slate-700">{product.rating}</span>
            <span className="text-xs text-slate-400">({product.reviewsCount})</span>
          </div>
        </div>

        {/* Price & Add to Cart */}
        <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base sm:text-lg font-black text-slate-900">
                {settings.currency}
                {product.price.toLocaleString()}
              </span>
            </div>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-xs text-slate-400 line-through">
                {settings.currency}
                {product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          <button
            onClick={() => addToCart(product, 1)}
            disabled={product.stock <= 0}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer ${
              product.stock <= 0
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/20 hover:shadow-md'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Add</span>
          </button>
        </div>
      </div>
    </div>
  );
};
