import React, { useState } from 'react';
import {
  X,
  Star,
  ShoppingBag,
  Heart,
  Check,
  AlertCircle,
  Truck,
  ShieldCheck,
  RotateCcw,
  Tag,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const ProductDetailModal: React.FC = () => {
  const {
    viewingProduct,
    setViewingProduct,
    settings,
    addToCart,
    toggleWishlist,
    isWishlisted,
  } = useStore();

  const [quantity, setQuantity] = useState(1);

  if (!viewingProduct) return null;

  const wishlisted = isWishlisted(viewingProduct.id);
  const discountPercent =
    viewingProduct.originalPrice && viewingProduct.originalPrice > viewingProduct.price
      ? Math.round(
          ((viewingProduct.originalPrice - viewingProduct.price) / viewingProduct.originalPrice) * 100
        )
      : null;

  const handleAddToCart = () => {
    addToCart(viewingProduct, quantity);
    setViewingProduct(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-slate-100 relative my-8">
        {/* Close Button */}
        <button
          onClick={() => setViewingProduct(null)}
          className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-white/90 backdrop-blur-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 shadow-md transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Product Image Column */}
          <div className="relative bg-slate-100 flex items-center justify-center p-6 md:p-8 aspect-square md:aspect-auto">
            {viewingProduct.badge && (
              <span className="absolute top-4 left-4 z-10 text-xs font-black uppercase px-3 py-1 rounded-full bg-rose-500 text-white shadow-md">
                {viewingProduct.badge}
              </span>
            )}
            <img
              src={viewingProduct.image}
              alt={viewingProduct.name}
              className="max-h-[380px] w-auto object-contain rounded-xl hover:scale-105 transition-transform duration-300"
            />
          </div>

          {/* Product Details Column */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              {/* Category & SKU */}
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-bold text-indigo-600 uppercase tracking-wider bg-indigo-50 px-2.5 py-1 rounded-md">
                  {viewingProduct.category}
                </span>
                <span className="font-mono text-slate-400">SKU: {viewingProduct.sku}</span>
              </div>

              {/* Title */}
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                {viewingProduct.name}
              </h2>

              {/* Rating */}
              <div className="flex items-center gap-2">
                <div className="flex text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(viewingProduct.rating)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-200'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-bold text-slate-700">{viewingProduct.rating}</span>
                <span className="text-xs text-slate-400">
                  ({viewingProduct.reviewsCount} verified reviews)
                </span>
              </div>

              {/* Price & Savings */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 flex items-baseline justify-between">
                <div>
                  <div className="text-2xl font-extrabold text-slate-900">
                    {settings.currency}
                    {(viewingProduct.price * quantity).toLocaleString()}
                  </div>
                  {viewingProduct.originalPrice && viewingProduct.originalPrice > viewingProduct.price && (
                    <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                      <span className="line-through">
                        {settings.currency}
                        {(viewingProduct.originalPrice * quantity).toLocaleString()}
                      </span>
                      {discountPercent && (
                        <span className="text-rose-600 font-bold bg-rose-50 px-1.5 py-0.5 rounded">
                          Save {discountPercent}%
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Stock status badge */}
                <div>
                  {viewingProduct.stock <= 0 ? (
                    <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2.5 py-1 rounded-full flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" /> Out of Stock
                    </span>
                  ) : viewingProduct.stock <= 5 ? (
                    <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2.5 py-1 rounded-full flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" /> Only {viewingProduct.stock} Left
                    </span>
                  ) : (
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> In Stock ({viewingProduct.stock})
                    </span>
                  )}
                </div>
              </div>

              {/* Description */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  Product Description
                </h4>
                <p className="text-sm text-slate-600 leading-relaxed max-h-36 overflow-y-auto pr-1">
                  {viewingProduct.description}
                </p>
              </div>

              {/* Specifications if present */}
              {viewingProduct.specs && viewingProduct.specs.length > 0 && (
                <div className="space-y-1.5 pt-1 border-t border-slate-100">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Key Specifications
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {viewingProduct.specs.map((spec, i) => (
                      <div key={i} className="bg-slate-50 p-2 rounded-lg">
                        <span className="font-medium text-slate-400 block text-[10px]">
                          {spec.label}
                        </span>
                        <span className="font-semibold text-slate-800">{spec.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Actions: Quantity & Add to Cart */}
            <div className="pt-4 border-t border-slate-100 space-y-3">
              {viewingProduct.stock > 0 && (
                <div className="flex items-center gap-4">
                  <span className="text-xs font-bold text-slate-700">Quantity:</span>
                  <div className="flex items-center border border-slate-200 rounded-xl bg-slate-50 overflow-hidden">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                    >
                      -
                    </button>
                    <span className="px-4 py-1.5 text-sm font-extrabold text-slate-800 bg-white">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => Math.min(viewingProduct.stock, q + 1))}
                      className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                    >
                      +
                    </button>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-3">
                <button
                  onClick={handleAddToCart}
                  disabled={viewingProduct.stock <= 0}
                  className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm shadow-md transition-all cursor-pointer ${
                    viewingProduct.stock <= 0
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/25 active:scale-98'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>
                    {viewingProduct.stock <= 0 ? 'Out of Stock' : `Add to Cart • ${settings.currency}${(viewingProduct.price * quantity).toLocaleString()}`}
                  </span>
                </button>

                <button
                  onClick={() => toggleWishlist(viewingProduct.id)}
                  className={`p-3.5 rounded-xl border transition-all ${
                    wishlisted
                      ? 'bg-rose-50 border-rose-200 text-rose-500'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                  title="Toggle wishlist"
                >
                  <Heart className={`w-5 h-5 ${wishlisted ? 'fill-rose-500' : ''}`} />
                </button>
              </div>

              {/* Guarantees */}
              <div className="grid grid-cols-3 gap-2 pt-2 text-[11px] text-slate-500 text-center">
                <div className="flex items-center justify-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Fast Delivery</span>
                </div>
                <div className="flex items-center justify-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Verified Warranty</span>
                </div>
                <div className="flex items-center justify-center gap-1">
                  <RotateCcw className="w-3.5 h-3.5 text-pink-500" />
                  <span>7-Day Return</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
