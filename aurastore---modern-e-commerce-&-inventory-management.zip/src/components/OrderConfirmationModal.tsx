import React from 'react';
import {
  CheckCircle2,
  Printer,
  ShoppingBag,
  Clock,
  Building2,
  CreditCard,
  Truck,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const OrderConfirmationModal: React.FC = () => {
  const { lastPlacedOrder, setLastPlacedOrder, settings, setCurrentView, setAdminTab } = useStore();

  if (!lastPlacedOrder) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 relative my-6">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 text-white p-6 sm:p-8 text-center relative overflow-hidden">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl mx-auto flex items-center justify-center text-white mb-3 shadow-inner">
            <CheckCircle2 className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-black">Thank You For Your Order!</h2>
          <p className="text-emerald-100 text-xs sm:text-sm mt-1">
            Order Reference: <strong className="font-mono text-white">{lastPlacedOrder.id}</strong>
          </p>
        </div>

        {/* Order Details Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Status Alert Banner */}
          <div
            className={`p-4 rounded-2xl border flex items-start gap-3 ${
              lastPlacedOrder.paymentStatus === 'paid'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : lastPlacedOrder.paymentStatus === 'pending_verification'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-indigo-50 border-indigo-200 text-indigo-900'
            }`}
          >
            <Clock className="w-5 h-5 shrink-0 mt-0.5 text-amber-600" />
            <div className="text-xs space-y-1">
              <p className="font-bold text-sm">
                {lastPlacedOrder.paymentStatus === 'paid'
                  ? 'Payment Confirmed & Verified!'
                  : lastPlacedOrder.paymentStatus === 'pending_verification'
                  ? 'Bank Deposit Slip Received - Pending Admin Verification'
                  : 'Cash on Delivery - Order Dispatched Soon'}
              </p>
              <p className="leading-relaxed">
                {lastPlacedOrder.paymentStatus === 'pending_verification'
                  ? 'Your bank transfer slip has been uploaded and transmitted to our finance team. You will receive an SMS and email notification once verified.'
                  : 'Our fulfillment center has received your order and is currently preparing your items for delivery.'}
              </p>
            </div>
          </div>

          {/* Customer & Shipping Summary */}
          <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <div>
              <p className="text-slate-400 font-semibold uppercase text-[10px]">Customer Name</p>
              <p className="font-bold text-slate-800 text-sm mt-0.5">{lastPlacedOrder.customerName}</p>
              <p className="text-slate-500 mt-1">{lastPlacedOrder.customerPhone}</p>
              <p className="text-slate-500">{lastPlacedOrder.customerEmail}</p>
            </div>
            <div>
              <p className="text-slate-400 font-semibold uppercase text-[10px]">Delivery Address</p>
              <p className="font-bold text-slate-800 mt-0.5">{lastPlacedOrder.shippingAddress}</p>
              <p className="text-slate-500">{lastPlacedOrder.city} {lastPlacedOrder.postalCode}</p>
              <p className="text-indigo-600 font-semibold mt-1 capitalize">
                Method: {lastPlacedOrder.paymentMethod.replace('_', ' ')}
              </p>
            </div>
          </div>

          {/* Ordered Items List */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Purchased Items
            </h4>
            <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden">
              {lastPlacedOrder.items.map((item, index) => (
                <div key={index} className="p-3 bg-white flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-10 h-10 rounded-lg object-cover border border-slate-200"
                    />
                    <div>
                      <p className="font-bold text-slate-900">{item.product.name}</p>
                      <p className="text-slate-500 text-[11px]">
                        Qty: {item.quantity} × {settings.currency}{item.product.price.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <span className="font-extrabold text-slate-900">
                    {settings.currency}{(item.product.price * item.quantity).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Bank Slip Thumbnail if uploaded */}
          {lastPlacedOrder.bankSlipUrl && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={lastPlacedOrder.bankSlipUrl}
                  alt="Bank transfer slip"
                  className="w-14 h-14 object-cover rounded-lg border border-slate-300"
                />
                <div>
                  <p className="font-bold text-slate-800">Bank Transfer Slip Attached</p>
                  <p className="text-[11px] text-slate-500">
                    Ref: {lastPlacedOrder.bankTransferRef || 'Uploaded via checkout'}
                  </p>
                </div>
              </div>
              <span className="text-[11px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-full">
                Verification Pending
              </span>
            </div>
          )}

          {/* Totals */}
          <div className="pt-2 border-t border-slate-100 space-y-1 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal</span>
              <span>{settings.currency}{lastPlacedOrder.subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Delivery Fee</span>
              <span>
                {lastPlacedOrder.shippingFee === 0
                  ? 'FREE'
                  : `${settings.currency}${lastPlacedOrder.shippingFee.toLocaleString()}`}
              </span>
            </div>
            <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-200">
              <span>Total Paid / Due</span>
              <span className="text-indigo-600 font-mono">
                {settings.currency}{lastPlacedOrder.total.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print Invoice</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setLastPlacedOrder(null);
                setCurrentView('admin');
                setAdminTab('orders');
              }}
              className="px-3.5 py-2.5 rounded-xl text-indigo-700 bg-indigo-50 hover:bg-indigo-100 text-xs font-bold transition-colors cursor-pointer"
            >
              View in Admin Panel
            </button>

            <button
              onClick={() => setLastPlacedOrder(null)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold px-5 py-2.5 rounded-xl shadow-md transition-all cursor-pointer"
            >
              <span>Continue Shopping</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
